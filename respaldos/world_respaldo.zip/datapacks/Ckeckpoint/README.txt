This Datapack was made using TheblueMan003's Compiler.
Therefor all variables & functions might have wierd name.
Please refers to MAPS.txt